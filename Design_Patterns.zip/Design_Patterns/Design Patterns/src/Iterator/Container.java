package Iterator;

public interface Container {
    public Iterator getIterator();
}
